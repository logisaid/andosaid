package com.androsaid.shop.ui.theme

import androidx.compose.ui.graphics.Color

// لوحة ألوان أندروسعيد — أخضر مزرق (Teal) مهني + لمسة كهرمانية
val Teal700 = Color(0xFF0F766E)
val Teal600 = Color(0xFF0D9488)
val Teal300 = Color(0xFF5EEAD4)
val Teal100 = Color(0xFFCCFBF1)
val Teal900 = Color(0xFF134E4A)

val Amber600 = Color(0xFFD97706)
val Amber300 = Color(0xFFFCD34D)

val White = Color(0xFFFFFFFF)
val Ink = Color(0xFF0F1B1A)
val SurfaceLight = Color(0xFFF7FAF9)

val DarkBg = Color(0xFF0B1413)
val DarkSurface = Color(0xFF10201E)
val DarkOnBg = Color(0xFFE6F2F0)
