package com.androsaid.shop.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable

private val LightColors = lightColorScheme(
    primary = Teal700,
    onPrimary = White,
    primaryContainer = Teal100,
    onPrimaryContainer = Teal900,
    secondary = Amber600,
    onSecondary = White,
    background = SurfaceLight,
    onBackground = Ink,
    surface = White,
    onSurface = Ink,
    surfaceVariant = Teal100,
    onSurfaceVariant = Teal900,
)

private val DarkColors = darkColorScheme(
    primary = Teal300,
    onPrimary = Teal900,
    primaryContainer = Teal700,
    onPrimaryContainer = Teal100,
    secondary = Amber300,
    onSecondary = Ink,
    background = DarkBg,
    onBackground = DarkOnBg,
    surface = DarkSurface,
    onSurface = DarkOnBg,
    surfaceVariant = Teal900,
    onSurfaceVariant = Teal100,
)

/**
 * ثيم التطبيق. يدعم الوضع الفاتح والغامق تلقائياً حسب النظام.
 * (سيصبح قابلاً للتبديل اليدوي من الإعدادات فالمرحلة 10.)
 */
@Composable
fun AndrosaidTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    content: @Composable () -> Unit
) {
    MaterialTheme(
        colorScheme = if (darkTheme) DarkColors else LightColors,
        typography = AndrosaidTypography,
        content = content
    )
}
