package com.androsaid.shop.ui.theme

import androidx.compose.material3.Typography

// الطباعة الافتراضية لـ Material 3 (كافية للمرحلة 0؛ يمكن تخصيص خط عربي لاحقاً)
val AndrosaidTypography = Typography()
