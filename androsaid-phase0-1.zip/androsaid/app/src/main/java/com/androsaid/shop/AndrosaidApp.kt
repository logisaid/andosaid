package com.androsaid.shop

import android.app.Application
import com.androsaid.shop.di.AppContainer

/**
 * نقطة انطلاق التطبيق. تنشئ حاوية الحقن اليدوي [AppContainer]
 * التي ستحمل قاعدة البيانات والمستودعات ابتداءً من المرحلة 1.
 */
class AndrosaidApp : Application() {

    lateinit var container: AppContainer
        private set

    override fun onCreate() {
        super.onCreate()
        container = AppContainer(applicationContext)
    }
}
