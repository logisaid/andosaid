package com.androsaid.shop.ui.navigation

import androidx.annotation.StringRes
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.BarChart
import androidx.compose.material.icons.filled.Dashboard
import androidx.compose.material.icons.filled.PhoneAndroid
import androidx.compose.material.icons.filled.PointOfSale
import androidx.compose.material.icons.filled.ReceiptLong
import androidx.compose.material.icons.filled.Settings
import androidx.compose.ui.graphics.vector.ImageVector
import com.androsaid.shop.R

/** كل وجهات التنقّل فالتطبيق. */
sealed class Dest(
    val route: String,
    @StringRes val labelRes: Int,
    val icon: ImageVector
) {
    data object Dashboard : Dest("dashboard", R.string.nav_dashboard, Icons.Filled.Dashboard)
    data object Inventory : Dest("inventory", R.string.nav_inventory, Icons.Filled.PhoneAndroid)
    data object Sales : Dest("sales", R.string.nav_sales, Icons.Filled.PointOfSale)
    data object Expenses : Dest("expenses", R.string.nav_expenses, Icons.Filled.ReceiptLong)
    data object Reports : Dest("reports", R.string.nav_reports, Icons.Filled.BarChart)
    data object Settings : Dest("settings", R.string.nav_settings, Icons.Filled.Settings)
    data object AddPhone : Dest("add_phone", R.string.action_add_phone, Icons.Filled.Add)

    companion object {
        /** الوجهات الخمس اللي كتبان فالشريط السفلي. */
        val bottomBar = listOf(Dashboard, Inventory, Sales, Expenses, Reports)

        /** كل الوجهات (للبحث عن العنوان حسب المسار). */
        val all = listOf(Dashboard, Inventory, Sales, Expenses, Reports, Settings, AddPhone)

        fun fromRoute(route: String?): Dest? = all.firstOrNull { it.route == route }
    }
}
