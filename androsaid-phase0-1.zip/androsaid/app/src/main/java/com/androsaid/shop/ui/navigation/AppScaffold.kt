package com.androsaid.shop.ui.navigation

import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.CenterAlignedTopAppBar
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExtendedFloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import com.androsaid.shop.R

/**
 * الهيكل الرئيسي للتطبيق: شريط علوي + شريط سفلي + زر عائم لإضافة هاتف + محتوى التنقّل.
 * الشريطان والزر كيتخبّاو فشاشة "إضافة هاتف" باش تكون تجربة إدخال مركّزة.
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AppScaffold() {
    val navController = rememberNavController()
    val backStackEntry by navController.currentBackStackEntryAsState()
    val currentRoute = backStackEntry?.destination?.route
    val current = Dest.fromRoute(currentRoute) ?: Dest.Dashboard
    val showChrome = current.route != Dest.AddPhone.route

    Scaffold(
        topBar = {
            if (showChrome) {
                CenterAlignedTopAppBar(
                    title = { Text(stringResource(current.labelRes)) },
                    actions = {
                        IconButton(onClick = { navController.navigate(Dest.Settings.route) }) {
                            Icon(Icons.Filled.Settings, contentDescription = stringResource(R.string.nav_settings))
                        }
                    },
                    colors = TopAppBarDefaults.centerAlignedTopAppBarColors()
                )
            }
        },
        bottomBar = {
            if (showChrome) {
                NavigationBar {
                    Dest.bottomBar.forEach { dest ->
                        NavigationBarItem(
                            selected = current.route == dest.route,
                            onClick = {
                                if (current.route != dest.route) {
                                    navController.navigate(dest.route) {
                                        popUpTo(Dest.Dashboard.route) { saveState = true }
                                        launchSingleTop = true
                                        restoreState = true
                                    }
                                }
                            },
                            icon = { Icon(dest.icon, contentDescription = stringResource(dest.labelRes)) },
                            label = { Text(stringResource(dest.labelRes)) }
                        )
                    }
                }
            }
        },
        floatingActionButton = {
            if (showChrome) {
                ExtendedFloatingActionButton(
                    onClick = { navController.navigate(Dest.AddPhone.route) },
                    icon = { Icon(Icons.Filled.Add, contentDescription = null) },
                    text = { Text(stringResource(R.string.action_add_phone)) }
                )
            }
        }
    ) { innerPadding ->
        NavHost(
            navController = navController,
            startDestination = Dest.Dashboard.route,
            modifier = Modifier.padding(innerPadding)
        ) {
            composable(Dest.Dashboard.route) { PlaceholderScreen(R.string.nav_dashboard) }
            composable(Dest.Inventory.route) { PlaceholderScreen(R.string.nav_inventory) }
            composable(Dest.Sales.route) { PlaceholderScreen(R.string.nav_sales) }
            composable(Dest.Expenses.route) { PlaceholderScreen(R.string.nav_expenses) }
            composable(Dest.Reports.route) { PlaceholderScreen(R.string.nav_reports) }
            composable(Dest.Settings.route) { PlaceholderScreen(R.string.nav_settings) }
            composable(Dest.AddPhone.route) { PlaceholderScreen(R.string.action_add_phone) }
        }
    }
}
