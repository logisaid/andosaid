package com.androsaid.shop.di

import android.content.Context

/**
 * حاوية الحقن اليدوي للتبعيات (بديل خفيف عن Hilt).
 * حالياً فارغة. فالمرحلة 1 غادي تُنشئ هنا:
 *   - قاعدة بيانات Room
 *   - الـ DAOs
 *   - المستودعات (Repositories)
 */
class AppContainer(private val appContext: Context) {
    // Phase 1: database, DAOs and repositories will be initialized here.
}
