// ملفات الإضافات (plugins) على مستوى المشروع — يتم تطبيقها فعلياً داخل app/build.gradle.kts
plugins {
    id("com.android.application") version "8.6.1" apply false
    id("org.jetbrains.kotlin.android") version "2.0.20" apply false
    id("org.jetbrains.kotlin.plugin.compose") version "2.0.20" apply false
}
